from django.apps import AppConfig


class LazySignupConfig(AppConfig):
    name = 'lazysignup'
    verbose_name = "Lazy Signup"
