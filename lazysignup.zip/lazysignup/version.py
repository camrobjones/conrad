# flake8: noqa
__version__ = '1.1.2'
