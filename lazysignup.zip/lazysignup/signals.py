import django.dispatch

converted = django.dispatch.Signal(providing_args=['user'])
