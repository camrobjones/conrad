# flake8: noqa
from .version import __version__

default_app_config = 'lazysignup.apps.LazySignupConfig'
