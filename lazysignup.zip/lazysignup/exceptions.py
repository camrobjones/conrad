class NotLazyError(TypeError):
    """ Raised when an operation is attempted on a non-lazy user """
